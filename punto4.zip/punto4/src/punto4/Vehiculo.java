package punto4;

public class Vehiculo { //Herencia Padre
	// Declaramos los atributos encapsulados
	protected String color;
	protected int puertas;
	protected int asientos;
	protected String marca;

	public String getColor() {
		return this.color;
	}

	public int getPuertas() {
		return this.puertas;
	}

	public int getAsientos() {
		return this.asientos;
	}

	public String getMarca() {
		return this.marca;
	}
}
