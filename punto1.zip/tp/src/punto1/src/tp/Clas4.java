package tp;

public class Clas4 {
	// triangulo//
	int base;
	int altura;

	public String toString() {

		String g = "base: " + base + " altura: " + altura;
		return g;
	}
}
