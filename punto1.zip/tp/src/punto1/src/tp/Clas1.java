package tp;

public class Clas1 {
	//figura trapecio//
	int altura=10;
	int base=6;

	public String toString() {
		String s= "altura: " + altura + " base: " + base;
		
		return s;

	}

}
