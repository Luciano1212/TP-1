package tp;

public class Main {

	public static void main(String[] args) {
		Clas1 tr;
		tr= new Clas1();
		System.out.println(tr.toString());
		
		Clas2 c;
		c= new Clas2();
		System.out.println(c.toString());
		
		Clas3 r;
		r=new Clas3();
		System.out.println(r.toString());
		
		Clas4 tri;
		tri=new Clas4();
		System.out.println(tri.toString());
		
		Clas5 ro;
		ro=new Clas5();
		System.out.println(ro.toString());
		
       
	}

}
