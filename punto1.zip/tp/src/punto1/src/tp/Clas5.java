package tp;

public class Clas5 {
	//rombo
	int base;
	int altura;
	
	
	public String toString(){
		String o= "base: " + base + " altura: " + altura;
		return o;
	}
}
