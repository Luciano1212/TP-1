package tp;

public class Clas2 {
	//Cuadrado//
	int altura;
	int base;
	
		public String toString(){
			
			String b= "altura: " + altura + " base: " + base;
		
			return b;
			
			
		}

}
