package tp;

public class Clas3 {
	// rectangulo[[//
	int base;
	int altura;

	public String toString() {

		String c = "base: " + base + " altura: " + altura;
		return c;

	}
}
