package punto3;

public class Clase {
	String Nombre;
	String Descripcion;
	String Dia;
	int hora;
	Profesor profesor;
	int valorcuota;
	
	public Clase(String nom, String descrip, String di, int hor, Profesor profe, int valor ){
		
		Nombre = nom;
		Descripcion = descrip;
		Dia = di;
		hora = hor;
		profesor = profe;
		valorcuota = valor;
		
		
	}

}
