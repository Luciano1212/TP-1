package punto3;

public class Profesor {
	
	String nombre;
    int aula;
    String materia;
    
    
    public Profesor(String nom, int clas, String mate){
    	
    	nombre = nom;
    	aula = clas;
    	materia = mate;
    	
    }

}
