package punto3;

public class Socios {

	String nombre;
	int telefono;
	int NroDocumento;
	String fechainscripcion;
	String fechanacimiento;
	String Domicilio;
	int altura;

	public Socios(String nombr, int tel, int NroDocu, String fechains,
			String fechanacimi, String Domici, int alt) {

		nombre = nombr;
		telefono = tel;
		NroDocumento = NroDocu;
		fechanacimiento = fechanacimi;
		fechainscripcion = fechains;
		Domicilio = Domici;
		altura = alt;

	}
}
