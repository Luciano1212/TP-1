package punto3;

public class Main {

	public static void main(String[] args) {
		Socios pedro = new Socios("Pepito", 0, 0, "Diciembre 18",
				"Noviembre 1998", "Alsina", 0);
		Profesor julio= new Profesor("Julio", 9 ,"Tango");
		Clase papa = new Clase("Ense�ansa","Tango","Lunes", 1900 , julio, 2900);
		Registro = new Registro(3, Clase, 13, "Si");
		
		
		System.out.println("FIN");

	
		
	}

}
