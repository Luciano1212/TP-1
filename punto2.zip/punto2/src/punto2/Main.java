package punto2;

public class Main {

	public static void main(String[] args) {
		control.Show();
        control.ShowMessage();	
        control.Show1();
        control.Show2();
        control.Show3();
        control.Show4();
 	}
	

}
